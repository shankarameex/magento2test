<?php
namespace Ameex\AdminLogger\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public function getActions()
    {
        return 1;
    }
}
