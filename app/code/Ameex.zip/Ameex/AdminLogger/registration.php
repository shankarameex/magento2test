<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\FrameWork\Component\ComponentRegistrar::MODULE,
	'Ameex_AdminLogger',
	__DIR__
	);
?>