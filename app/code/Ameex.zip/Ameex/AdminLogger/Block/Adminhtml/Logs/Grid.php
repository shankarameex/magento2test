<?php
namespace Ameex\AdminLogger\Block\Adminhtml\Logs;
 
use Magento\Backend\Block\Widget\Grid as WidgetGrid;
 
class Grid extends WidgetGrid
{
   
}